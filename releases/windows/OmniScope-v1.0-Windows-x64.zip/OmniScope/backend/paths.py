"""
OmniScope OSINT - Central Path Resolution Utility
Ensures absolute reliability in path location across:
- Standalone development mode
- PyInstaller frozen onedir execution
"""
import os
import sys
import io

class NullStream:
    def write(self, data): return len(data) if data else 0
    def flush(self): pass
    def isatty(self): return False
    def fileno(self): raise io.UnsupportedOperation("No fileno")
    def reconfigure(self, **kwargs): pass
    @property
    def buffer(self): return self

if sys.stdout is None:
    try:
        sys.stdout = open(os.devnull, "w", encoding="utf-8")
    except Exception:
        sys.stdout = NullStream()

if sys.stderr is None:
    try:
        sys.stderr = open(os.devnull, "w", encoding="utf-8")
    except Exception:
        sys.stderr = NullStream()

def get_base_dir() -> str:
    """Returns the root directory of the application (where backend/ and frontend/ live)."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    # backend/paths.py -> parent of backend is project root
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def get_data_dir() -> str:
    """Returns the backend data directory containing databases and caches."""
    env_dir = os.environ.get("OMNISCOPE_DATA_DIR")
    if env_dir and os.path.isdir(env_dir):
        return env_dir

    base = get_base_dir()
    candidates = [
        os.path.join(base, "backend", "data"),
        os.path.join(base, "data"),
    ]
    if hasattr(sys, "_MEIPASS"):
        candidates.append(os.path.join(sys._MEIPASS, "backend", "data"))
        candidates.append(os.path.join(sys._MEIPASS, "data"))

    for c in candidates:
        if os.path.isdir(c):
            return c

    fallback = os.path.join(base, "backend", "data")
    os.makedirs(fallback, exist_ok=True)
    return fallback

def get_frontend_dir() -> str:
    """Returns the frontend assets directory."""
    base = get_base_dir()
    candidates = [
        os.path.join(base, "frontend"),
    ]
    if hasattr(sys, "_MEIPASS"):
        candidates.append(os.path.join(sys._MEIPASS, "frontend"))

    for c in candidates:
        if os.path.isdir(c):
            return c

    fallback = os.path.join(base, "frontend")
    os.makedirs(fallback, exist_ok=True)
    return fallback

BASE_DIR = get_base_dir()
DATA_DIR = get_data_dir()
FRONTEND_DIR = get_frontend_dir()
