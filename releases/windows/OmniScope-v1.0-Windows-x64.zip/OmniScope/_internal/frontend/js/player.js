/**
 * CYBER-SPECTRE-NEXUS: Universal Video & Stream Player Engine (100% NO-KEY & FREE PROVIDERS)
 * Robust playback for:
 * - Panomax & Roundshot 360° Gigapixel Live Panoramas (Zugspitze, Matterhorn, Hamburg, Berlin, etc.)
 * - HLS (.m3u8) with automatic local CORS proxy fallback
 * - YouTube Live embeds with video ID parsing
 * - High-frequency auto-refreshing snapshot cameras with CORS proxy
 * - Direct Live Stream & Snapshot Diagnostics (ZERO FAKE // ZERO SATELLITE FALLBACK)
 */

// ZERO FAKES / ZERO SIMULATION - All camera data loaded dynamically from SQLite API

/**
 * Comprehensive Country Resolver:
 * Accurate geographic boundaries for European nations and global sectors.
 * ZERO SIMULATION - Never default European nodes or international telemetry to USA!
 */
function resolveCountry(lat, lon, fallbackCountry = '') {
    const fb = (fallbackCountry || '').trim();
    const fbLower = fb.toLowerCase();

    if (lat == null || lon == null || isNaN(Number(lat)) || isNaN(Number(lon))) {
        if (fb && !['usa', 'us', 'united states'].includes(fbLower)) {
            return fb;
        }
        return 'Europa';
    }

    const nLat = Number(lat);
    const nLon = Number(lon);

    // 1. If explicit authentic country name is provided, use it directly
    if (fbLower.includes('deutschland') || fbLower === 'germany' || fbLower === 'de') return 'Deutschland (DE)';
    if (fbLower.includes('österreich') || fbLower === 'austria' || fbLower === 'at') return 'Österreich (AT)';
    if (fbLower.includes('schweiz') || fbLower === 'switzerland' || fbLower === 'ch') return 'Schweiz (CH)';
    if (fbLower.includes('frankreich') || fbLower === 'france' || fbLower === 'fr') return 'Frankreich (FR)';
    if (fbLower.includes('kingdom') || fbLower === 'uk' || fbLower === 'gb' || fbLower.includes('britain')) return 'United Kingdom (UK)';
    if (fbLower.includes('italien') || fbLower === 'italy' || fbLower === 'it') return 'Italien (IT)';
    if (fbLower.includes('spanien') || fbLower === 'spain' || fbLower === 'es') return 'Spanien (ES)';
    if (fbLower.includes('norway') || fbLower.includes('norwegen') || fbLower === 'no') return 'Norwegen (NO)';
    if (fbLower.includes('sweden') || fbLower.includes('schweden') || fbLower === 'se') return 'Schweden (SE)';
    if (fbLower.includes('poland') || fbLower.includes('polen') || fbLower === 'pl') return 'Polen (PL)';
    if (fbLower.includes('netherlands') || fbLower.includes('niederlande') || fbLower === 'nl') return 'Niederlande (NL)';
    if (fbLower.includes('belgium') || fbLower.includes('belgien') || fbLower === 'be') return 'Belgien (BE)';

    // 2. Geographic Bounding Boxes for Coordinate Resolution
    // Germany: lat 47.2..55.1, lon 5.8..15.1
    if (nLat >= 47.4 && nLat <= 55.1 && nLon >= 5.8 && nLon <= 15.1 && (nLat >= 47.6 || fbLower.includes('germany') || fbLower.includes('deutschland') || !fbLower.includes('austria'))) {
        return 'Deutschland (DE)';
    }

    // Switzerland: lat 45.8..47.8, lon 5.9..10.5
    if (nLat >= 45.8 && nLat <= 47.8 && nLon >= 5.9 && nLon <= 10.5) {
        return 'Schweiz (CH)';
    }

    // Austria: lat 46.3..49.1, lon 9.5..17.2
    if (nLat >= 46.3 && nLat <= 49.1 && nLon >= 9.5 && nLon <= 17.2) {
        return 'Österreich (AT)';
    }

    // Germany broad
    if (nLat >= 47.0 && nLat <= 55.5 && nLon >= 5.5 && nLon <= 15.5) {
        return 'Deutschland (DE)';
    }

    // United Kingdom: lat 49.9..59.5, lon -8.0..2.0
    if (nLat >= 49.9 && nLat <= 59.5 && nLon >= -8.0 && nLon <= 2.0) {
        if (nLat >= 51.1 || nLon <= -1.8 || fbLower.includes('uk') || fbLower.includes('kingdom') || fbLower.includes('gb') || fbLower.includes('london')) {
            return 'United Kingdom (UK)';
        }
    }

    // France: lat 42.0..51.5, lon -5.0..8.5 -> 'Frankreich (FR)'
    if (nLat >= 42.0 && nLat <= 51.5 && nLon >= -5.0 && nLon <= 8.5) {
        return 'Frankreich (FR)';
    }

    // United Kingdom fallback
    if (nLat >= 49.9 && nLat <= 59.5 && nLon >= -8.0 && nLon <= 2.0) {
        return 'United Kingdom (UK)';
    }

    // Italy: lat 36.5..47.1, lon 6.5..18.5 -> 'Italien (IT)'
    if (nLat >= 36.5 && nLat <= 47.1 && nLon >= 6.5 && nLon <= 18.5) {
        return 'Italien (IT)';
    }

    // Spain: lat 36.0..44.0, lon -9.5..3.5 -> 'Spanien (ES)'
    if (nLat >= 36.0 && nLat <= 44.0 && nLon >= -9.5 && nLon <= 3.5) {
        return 'Spanien (ES)';
    }

    // Broader Europe: lat 35..72, lon -10..35 -> never default to 'USA'! Default to 'Europa'.
    if (nLat >= 35.0 && nLat <= 72.0 && nLon >= -10.0 && nLon <= 35.0) {
        if (fb && !['usa', 'us', 'united states'].includes(fbLower)) {
            return fb;
        }
        return 'Europa';
    }

    // Regions outside Europe
    if (fb && !['usa', 'us', 'united states'].includes(fbLower)) {
        return fb;
    }
    if (nLon < -50.0 && nLat >= 24.0 && nLat <= 72.0) {
        return 'USA';
    }
    return fb || 'International';
}
window.resolveCountry = resolveCountry;

class StreamPlayer {
    constructor(containerId) {
        this.containerId = containerId;
        this.container = document.getElementById(containerId);
        this.hls = null;
        this.hlsSafetyTimeout = null;
        this.refreshInterval = null;
        this.timelapseTimer = null;
        this.timelapsePlaying = false;
        this.timelapseSpeed = 200; // 200ms = 5 FPS
        this.timelapseFrames = [];
        this.timelapseIndex = 0;
        this.currentUrl = null;
        this.currentType = null;
        this.currentCamData = null;
        this.currentTimeline = 'live';

        // MON-02 Omni View Monitor State
        this.currentOmniTab = 'webcams';
        this.lastRealCam = null;

        // Auto-resolve MON-02 acquisition freeze immediately
        if (typeof document !== 'undefined') {
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', () => {
                    this.container = document.getElementById(this.containerId);
                    this.checkAndLoadInitialFeed();
                });
            } else {
                setTimeout(() => this.checkAndLoadInitialFeed(), 50);
            }
        }
    }

    checkAndLoadInitialFeed() {
        this.container = document.getElementById(this.containerId) || document.getElementById('player-container') || document.getElementById('cam-player');
        if (!this.container) return;
        const text = (this.container.innerText || this.container.textContent || '').trim();
        const isInitialState = !this.currentCamData || text.includes('ACQUIRING LIVE FEED') || this.container.children.length === 0;
        if (isInitialState) {
            fetch('/api/cameras/catalog?provider=all&limit=10')
                .then(r => r.json())
                .then(data => {
                    if (data && data.cameras && data.cameras.length > 0) {
                        this.playCam(data.cameras[0], 'live');
                    }
                })
                .catch(err => console.warn('checkAndLoadInitialFeed error:', err));
        }
    }

    loadCamera(camData) {
        return this.playCam(camData, 'live');
    }

    playCam(camData, preferredTimeline = 'live') {
        this.currentCamData = camData;
        this.currentTimeline = preferredTimeline;

        // All cameras are real — no flock or telemetry detection needed
        this.lastRealCam = camData;
        this.updateOmniTabUI('webcams');

        // Render adaptive timeline bar for available horizons
        this.renderTimelineBar(camData);
        this.setTimelineMode(preferredTimeline);
    }

    updateOmniTabUI(tabName) {
        this.currentOmniTab = tabName;
        const typePill = document.getElementById('mon02-active-type-pill');
        if (typePill) {
            typePill.innerText = '🔵 WEBCAM STREAM';
            typePill.style.background = 'rgba(56,189,248,0.18)';
            typePill.style.color = '#38bdf8';
            typePill.style.borderColor = '#0284c7';
        }
        document.querySelectorAll('.omni-tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.omniTab === tabName);
        });
    }

    hasRealImage(camData) {
        if (!camData) return null;
        const urls = [camData.stream_url, camData.preview_url, camData.poster_url, camData.thumbnail_url];
        for (const u of urls) {
            if (typeof u === 'string' && (u.startsWith('http') || u.startsWith('/api/'))) {
                // Must not be an openstreetmap or generic html link
                if (u.includes('openstreetmap.org') || u.includes('hafen-hamburg.de') || (u.includes('.html') && !u.includes('.jpg'))) {
                    continue;
                }
                // ZERO-STOCK-PHOTO: Never allow zugspitze-ost or cams/150 on non-zugspitze cams
                const camId = (camData.id || '').toLowerCase();
                const camTitle = (camData.title || '').toLowerCase();
                if ((u.includes('zugspitze-ost') || u.includes('cams/150')) && !camId.includes('zugspitze') && !camTitle.includes('zugspitze')) {
                    continue;
                }
                if (u.includes('/proxy/camera-recon') ||
                    u.match(/\.(jpg|jpeg|png|webp)($|\?)/i) || 
                    u.includes('/image') || 
                    u.includes('jamcams') || 
                    u.includes('cctv') || 
                    u.includes('snapshot') ||
                    u.includes('traffic') ||
                    u.includes('camera') ||
                    u.includes('panodata') ||
                    u.includes('foto-webcam') ||
                    u.includes('/cams/') ||
                    (camData.stream_type === 'snapshot' && !u.includes('.m3u8'))) {
                    return u;
                }
            }
        }
        // Fallback: If preview_url or thumbnail_url exists and not html
        if (typeof camData.preview_url === 'string' && (camData.preview_url.startsWith('http') || camData.preview_url.startsWith('/api/')) && !camData.preview_url.includes('.html')) {
            return camData.preview_url;
        }
        if (typeof camData.thumbnail_url === 'string' && (camData.thumbnail_url.startsWith('http') || camData.thumbnail_url.startsWith('/api/')) && !camData.thumbnail_url.includes('.html')) {
            return camData.thumbnail_url;
        }
        return null;
    }

    extractSnapshotsArray(camData) {
        if (!camData) return null;
        if (Array.isArray(camData.snapshots) && camData.snapshots.length > 1) {
            return camData.snapshots;
        }
        if (Array.isArray(camData.daylight_shots) && camData.daylight_shots.length > 1) {
            return camData.daylight_shots;
        }
        if (Array.isArray(camData.daylight_images) && camData.daylight_images.length > 1) {
            return camData.daylight_images;
        }
        if (camData.images) {
            if (Array.isArray(camData.images.daylight_shots) && camData.images.daylight_shots.length > 1) {
                return camData.images.daylight_shots;
            }
            if (Array.isArray(camData.images.snapshots) && camData.images.snapshots.length > 1) {
                return camData.images.snapshots;
            }
            if (Array.isArray(camData.images) && camData.images.length > 1) {
                return camData.images;
            }
        }
        return null;
    }

    setTimelineMode(mode) {
        if (!this.currentCamData) return;
        this.currentTimeline = mode;
        this.updateActiveTimelineBtn(mode);

        const cam = this.currentCamData;

        // 0. Authentic Live Stream & Video Pipeline (100% Real Feeds)

        // 1. YouTube Live Stream & Verified IFrame Embeds
        if (cam.stream_type === 'iframe_embed' || cam.stream_type === 'youtube' || (cam.stream_url && (cam.stream_url.includes('youtube.com') || cam.stream_url.includes('youtu.be')))) {
            this.play(cam.stream_url, 'youtube');
            return;
        }

        // 2. 360° Panoramas (Panomax & Roundshot - 100% Free & No-Key)
        if (cam.provider === 'Panomax' || (cam.stream_url && cam.stream_url.includes('panomax'))) {
            this.play(cam.stream_url, 'panomax_archive');
            return;
        }
        if (cam.provider === 'Roundshot' || (cam.stream_url && cam.stream_url.includes('roundshot'))) {
            this.play(cam.stream_url, 'roundshot_archive');
            return;
        }

        // 2b. Windy Webcams (Live Player & Timelapses - 100% Real Feeds)
        if (cam.provider === 'Windy' || cam.stream_type === 'windy' || (cam.stream_url && cam.stream_url.includes('windy.com'))) {
            let targetUrl = cam.stream_url;
            if (cam.timelines && cam.timelines[mode]) {
                targetUrl = cam.timelines[mode];
            } else if (cam.timelines && cam.timelines.live) {
                targetUrl = cam.timelines.live;
            }
            if (targetUrl && targetUrl.includes('/embed/player/')) {
                this.play(targetUrl, 'iframe_embed');
                return;
            } else if (targetUrl && (targetUrl.match(/\.(jpg|jpeg|png|webp)/i) || targetUrl.includes('imgproxy.windy.com'))) {
                this.playLiveSnapshot(cam, targetUrl);
                return;
            }
        }

        // 3. EarthCam & Skyline Webcams Embeds
        if (cam.provider === 'EarthCam' || (cam.stream_url && cam.stream_url.includes('earthcam'))) {
            this.play(cam.stream_url, 'earthcam_embed');
            return;
        }
        if (cam.provider === 'Skyline' || (cam.stream_url && cam.stream_url.includes('skylinewebcams'))) {
            const realImg = this.hasRealImage(cam);
            if (realImg) {
                this.playLiveSnapshot(cam, realImg);
                return;
            }
            this.play(cam.stream_url, 'skyline_embed');
            return;
        }

        // 4. HLS .m3u8 live feeds
        if (cam.stream_type === 'hls' || (cam.stream_url && cam.stream_url.includes('.m3u8'))) {
            this.play(cam.stream_url, 'hls');
            return;
        }

        // 5. Timelapse mode with snapshots sequence
        if (mode === 'timelapse' || mode === 'timelapse_5fps') {
            const snapshots = this.extractSnapshotsArray(cam);
            if (snapshots && snapshots.length > 1) {
                this.playSnapshotsSequence(cam, snapshots);
                return;
            }
        }

        // 6. Direct Photo / Snapshot Feeds
        const realImg = this.hasRealImage(cam);
        if (realImg) {
            this.playLiveSnapshot(cam, realImg);
            return;
        }

        // 7. Generic iframe embed if stream_url is present
        if (cam.stream_url && cam.stream_url.startsWith('http') && !cam.stream_url.includes('example.com')) {
            this.play(cam.stream_url, 'iframe_embed');
            return;
        }

        // 8. Direct camera feed offline check (Kein Fake, keine Satelliten-Simulation)
        this.showOffline(cam, 'Kein aktiver Video- oder Bild-Stream für diesen Standort verfügbar');
    }

    renderTimelineBar(camData) {
        const bar = document.getElementById('cam-timeline-bar');
        if (!bar) return;
        bar.innerHTML = '';
        
        const horizons = [
            { id: 'live', label: '🔴 LIVE' },
            { id: 'timelapse', label: '⚡ TIMELAPSE' },
            { id: 'day', label: '24H (DAY)' },
            { id: 'month', label: '30D (MONTH)' },
            { id: 'year', label: '1Y (YEAR)' },
            { id: 'lifetime', label: 'LIFETIME (ARCHIVE)' }
        ];

        horizons.forEach(h => {
            const btn = document.createElement('button');
            const isActive = (this.currentTimeline === h.id) || (h.id === 'timelapse' && this.currentTimeline === 'timelapse_5fps');
            btn.className = `timeline-btn ${isActive ? 'active' : ''}`;
            btn.dataset.timeline = h.id;
            btn.innerText = h.label;
            btn.onclick = () => {
                this.setTimelineMode(h.id);
            };
            bar.appendChild(btn);
        });
    }

    updateActiveTimelineBtn(mode) {
        document.querySelectorAll('#cam-timeline-bar .timeline-btn').forEach(btn => {
            const bId = btn.dataset.timeline;
            const isMatch = (bId === mode) || (bId === 'timelapse' && mode === 'timelapse_5fps') || (bId === 'timelapse_5fps' && mode === 'timelapse');
            if (isMatch) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });
    }

    playSnapshotsSequence(camData, rawSnapshots) {
        this.destroy();
        this.container = document.getElementById(this.containerId) || document.getElementById('player-container') || document.getElementById('cam-player');
        if (!this.container) return;

        // Normalize raw snapshots from earliest to latest
        const frames = (rawSnapshots || []).map((item, idx) => {
            if (typeof item === 'string') {
                return {
                    index: idx,
                    url: item,
                    label: `SHOT ${idx + 1} / ${rawSnapshots.length}`
                };
            }
            return {
                index: idx,
                url: item.url || item.preview || item.src,
                label: item.time ? new Date(item.time).toLocaleString() : `SHOT ${idx + 1} / ${rawSnapshots.length}`
            };
        }).filter(f => Boolean(f.url));

        if (frames.length === 0) {
            this.showOffline(camData, 'Keine Zeitraffer-Bilder verfügbar');
            return;
        }

        this.timelapseFrames = frames;
        this.timelapseIndex = 0;
        this.timelapsePlaying = true;

        this.container.innerHTML = `
            <div style="position:relative;width:100%;height:100%;background:#000;display:flex;flex-direction:column;overflow:hidden;">
                <!-- Top Status Badge -->
                <div style="position:absolute;top:8px;left:8px;z-index:10;display:flex;gap:6px;align-items:center;background:rgba(9,14,23,0.92);padding:4px 10px;border-radius:3px;border:1px solid #1e293b;font-family:var(--font-mono);font-size:0.72rem;">
                    <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#38bdf8;box-shadow:0 0 8px #38bdf8;animation:reticle-pulse 0.8s infinite;"></span>
                    <span style="color:#fff;font-weight:bold;">⚡ 5 FPS ARCHIVE TIMELAPSE</span>
                    <span id="timelapse-frame-counter" style="color:#38bdf8;">[1 / ${frames.length}]</span>
                </div>

                <!-- Main Image Display -->
                <div style="flex:1;display:flex;align-items:center;justify-content:center;position:relative;background:#030712;">
                    <img id="timelapse-display-img" src="${frames[0].url}" style="max-width:100%;max-height:100%;object-fit:contain;" />
                    <div id="timelapse-timestamp-overlay" style="position:absolute;bottom:10px;right:10px;background:rgba(0,0,0,0.85);color:#38bdf8;font-family:var(--font-mono);font-size:0.75rem;padding:3px 8px;border-radius:3px;border:1px solid #1e293b;">
                        ${frames[0].label}
                    </div>
                </div>

                <!-- Tactical Bottom Bar Controls -->
                <div style="background:rgba(9,14,23,0.95);border-top:1px solid #1e293b;padding:6px 12px;display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:8px;font-family:var(--font-mono);font-size:0.72rem;z-index:15;">
                    <div style="display:flex;align-items:center;gap:6px;">
                        <button id="btn-timelapse-playpause" class="ops-btn active" style="padding:2px 8px;font-size:0.7rem;">⏸ PAUSE</button>
                        <button id="btn-timelapse-prev" class="ops-btn" style="padding:2px 6px;">⏮</button>
                        <button id="btn-timelapse-next" class="ops-btn" style="padding:2px 6px;">⏭</button>
                        <span style="color:var(--text-muted);font-size:0.65rem;margin-left:4px;">SPEED:</span>
                        <select id="select-timelapse-fps" style="background:#090e17;color:#38bdf8;border:1px solid #1e293b;font-size:0.68rem;padding:2px 4px;border-radius:3px;">
                            <option value="500">2 FPS (Slow)</option>
                            <option value="200" selected>5 FPS (Default)</option>
                            <option value="100">10 FPS (Fast)</option>
                        </select>
                    </div>
                    <div style="flex:1;max-width:300px;display:flex;align-items:center;gap:8px;">
                        <input id="timelapse-scrubber" type="range" min="0" max="${frames.length - 1}" value="0" style="width:100%;accent-color:#38bdf8;cursor:pointer;" />
                    </div>
                </div>
            </div>
        `;

        const displayImg = document.getElementById('timelapse-display-img');
        const counterEl = document.getElementById('timelapse-frame-counter');
        const timestampEl = document.getElementById('timelapse-timestamp-overlay');
        const scrubber = document.getElementById('timelapse-scrubber');
        const playPauseBtn = document.getElementById('btn-timelapse-playpause');
        const prevBtn = document.getElementById('btn-timelapse-prev');
        const nextBtn = document.getElementById('btn-timelapse-next');
        const fpsSelect = document.getElementById('select-timelapse-fps');

        const updateFrame = (index) => {
            this.timelapseIndex = (index + frames.length) % frames.length;
            const curFrame = frames[this.timelapseIndex];
            if (displayImg) displayImg.src = curFrame.url;
            if (counterEl) counterEl.innerText = `[${this.timelapseIndex + 1} / ${frames.length}]`;
            if (timestampEl) timestampEl.innerText = curFrame.label;
            if (scrubber) scrubber.value = this.timelapseIndex;
        };

        const startLoop = () => {
            if (this.timelapseTimer) clearInterval(this.timelapseTimer);
            this.timelapseTimer = setInterval(() => {
                if (this.timelapsePlaying) {
                    updateFrame(this.timelapseIndex + 1);
                }
            }, this.timelapseSpeed);
        };

        if (playPauseBtn) {
            playPauseBtn.onclick = () => {
                this.timelapsePlaying = !this.timelapsePlaying;
                playPauseBtn.innerText = this.timelapsePlaying ? '⏸ PAUSE' : '▶ PLAY';
                playPauseBtn.classList.toggle('active', this.timelapsePlaying);
            };
        }

        if (prevBtn) {
            prevBtn.onclick = () => {
                this.timelapsePlaying = false;
                if (playPauseBtn) {
                    playPauseBtn.innerText = '▶ PLAY';
                    playPauseBtn.classList.remove('active');
                }
                updateFrame(this.timelapseIndex - 1);
            };
        }

        if (nextBtn) {
            nextBtn.onclick = () => {
                this.timelapsePlaying = false;
                if (playPauseBtn) {
                    playPauseBtn.innerText = '▶ PLAY';
                    playPauseBtn.classList.remove('active');
                }
                updateFrame(this.timelapseIndex + 1);
            };
        }

        if (scrubber) {
            scrubber.oninput = (e) => {
                this.timelapsePlaying = false;
                if (playPauseBtn) {
                    playPauseBtn.innerText = '▶ PLAY';
                    playPauseBtn.classList.remove('active');
                }
                updateFrame(parseInt(e.target.value, 10));
            };
        }

        if (fpsSelect) {
            fpsSelect.onchange = (e) => {
                this.timelapseSpeed = parseInt(e.target.value, 10);
                startLoop();
            };
        }

        // Background preload next images
        frames.slice(1, 15).forEach(f => {
            const img = new Image();
            img.src = f.url;
        });

        startLoop();
    }

    playLiveSnapshot(camData, overrideUrl = null) {
        this.destroy();
        this.currentCamData = camData || this.currentCamData;
        this.container = document.getElementById(this.containerId) || document.getElementById('player-container') || document.getElementById('cam-player');
        if (!this.container) return;

        const imgUrl = overrideUrl || this.hasRealImage(camData);
        if (!imgUrl) {
            this.showOffline(camData, 'SENSOR OFFLINE // BILDQUELLE ANTWORTET NICHT (HTTP 502/504)');
            return;
        }

        const fallbackUrl = (camData && camData.preview_url && camData.preview_url !== imgUrl)
            ? camData.preview_url
            : ((camData && camData.thumbnail_url && camData.thumbnail_url !== imgUrl) ? camData.thumbnail_url : '');

        const prov = (camData && camData.provider) ? camData.provider.toUpperCase() : 'WEBCAM';

        this.container.innerHTML = `
            <div style="position:relative;width:100%;height:100%;background:#000;display:flex;flex-direction:column;overflow:hidden;">
                <!-- Top Status Badge -->
                <div style="position:absolute;top:8px;left:8px;z-index:10;display:flex;gap:6px;align-items:center;background:rgba(9,14,23,0.92);padding:4px 10px;border-radius:3px;border:1px solid #1e293b;font-family:var(--font-mono);font-size:0.72rem;">
                    <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#10b981;box-shadow:0 0 8px #10b981;animation:reticle-pulse 1s infinite;"></span>
                    <span style="color:#fff;font-weight:bold;">LIVE SNAPSHOT TRANSMISSION</span>
                    <span style="color:var(--text-muted);font-size:0.65rem;">// ${prov} DIRECT FEED</span>
                </div>

                <!-- Main Image Display -->
                <div id="live-snapshot-wrapper" style="flex:1;display:flex;align-items:center;justify-content:center;position:relative;background:#030712;">
                    <img id="live-snapshot-img" style="max-width:100%;max-height:100%;object-fit:contain;" />
                </div>

                <!-- Tactical Bottom Bar -->
                <div style="background:rgba(9,14,23,0.95);border-top:1px solid #1e293b;padding:6px 12px;display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:8px;font-family:var(--font-mono);font-size:0.72rem;z-index:15;">
                    <div style="display:flex;align-items:center;gap:8px;">
                        <button id="btn-snap-refresh" class="ops-btn" style="padding:2px 8px;font-size:0.7rem;">REFRESH NOW</button>
                        <button id="btn-snap-next" class="ops-btn active" style="padding:2px 8px;font-size:0.7rem;background:#0284c7;color:#fff;font-weight:bold;">▶ NÄCHSTE KAMERA LADEN</button>
                    </div>
                    <div id="snap-timer-readout" style="color:#38bdf8;">NEXT AUTO-SYNC IN 10S</div>
                </div>
            </div>
        `;

        const snapImg = document.getElementById('live-snapshot-img');
        const timerReadout = document.getElementById('snap-timer-readout');
        const refreshBtn = document.getElementById('btn-snap-refresh');
        const nextBtn = document.getElementById('btn-snap-next');

        if (nextBtn) {
            nextBtn.onclick = () => this.loadNextRealCam();
        }

        let triedProxy = false;
        let triedFallback = false;

        const handleImageError = () => {
            if (!triedProxy) {
                triedProxy = true;
                if (snapImg) {
                    snapImg.src = `/api/proxy/image?url=${encodeURIComponent(imgUrl)}&_t=${Date.now()}`;
                }
            } else if (!triedFallback && fallbackUrl && fallbackUrl !== imgUrl) {
                triedFallback = true;
                if (snapImg) {
                    snapImg.src = fallbackUrl;
                }
            } else {
                // If proxy fails with 502/504 or network error, show authentic offline status
                this.showOffline(camData, 'SENSOR OFFLINE // BILDQUELLE ANTWORTET NICHT (HTTP 502/504)');
            }
        };

        if (snapImg) {
            snapImg.onerror = handleImageError;
            snapImg.src = imgUrl;
        }

        let secondsRemaining = 10;
        const doRefresh = () => {
            secondsRemaining = 10;
            if (snapImg) {
                const sep = imgUrl.includes('?') ? '&' : '?';
                if (triedProxy) {
                    snapImg.src = `/api/proxy/image?url=${encodeURIComponent(imgUrl)}&_t=${Date.now()}`;
                } else {
                    snapImg.src = `${imgUrl}${sep}_t=${Date.now()}`;
                }
            }
            if (timerReadout) timerReadout.innerText = `SYNCED // NEXT IN 10S`;
        };

        if (refreshBtn) refreshBtn.onclick = doRefresh;

        this.refreshInterval = setInterval(() => {
            secondsRemaining--;
            if (secondsRemaining <= 0) {
                doRefresh();
            } else if (timerReadout) {
                timerReadout.innerText = `NEXT AUTO-SYNC IN ${secondsRemaining}S`;
            }
        }, 1000);
    }

    showOffline(camData, reason = 'SENSOR OFFLINE // BILDQUELLE ANTWORTET NICHT (HTTP 502/504)') {
        this.destroy();
        this.container = document.getElementById(this.containerId) || document.getElementById('player-container') || document.getElementById('cam-player');
        if (!this.container) return;

        const title = camData ? (camData.title || 'Live Webcam') : 'Kamera-Feed';
        const prov = camData ? (camData.provider || 'Webcam') : 'Netzwerk';
        const loc = camData ? `${camData.city || ''} ${camData.country ? '(' + camData.country + ')' : ''}`.trim() : '';
        const coords = (camData && camData.lat && camData.lon) ? ` // POS: ${Number(camData.lat).toFixed(4)}°, ${Number(camData.lon).toFixed(4)}°` : '';
        const extUrl = camData ? (camData.stream_url || camData.live_video_url || '') : '';

        this.container.innerHTML = `
            <div style="position:relative;width:100%;height:100%;background:#060a12;display:flex;flex-direction:column;align-items:center;justify-content:center;font-family:var(--font-mono);color:#94a3b8;padding:16px;text-align:center;overflow-y:auto;box-sizing:border-box;">
                <!-- Header Indicator -->
                <div style="position:absolute;top:10px;left:10px;display:flex;align-items:center;gap:6px;font-size:0.7rem;color:#ef4444;background:rgba(239,68,68,0.1);padding:3px 8px;border-radius:3px;border:1px solid rgba(239,68,68,0.3);">
                    <span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:#ef4444;"></span>
                    <span>SENSOR OFFLINE // HTTP 502/504</span>
                </div>

                <div style="font-size:2.4rem;margin-bottom:12px;opacity:0.9;">📡</div>
                <div style="color:#ef4444;font-weight:bold;font-size:0.92rem;margin-bottom:6px;letter-spacing:1px;">
                    SENSOR OFFLINE // BILDQUELLE ANTWORTET NICHT (HTTP 502/504)
                </div>
                <div style="color:#f8fafc;font-size:0.85rem;margin-bottom:4px;font-weight:600;max-width:80%;">
                    ${title}
                </div>
                <div style="color:#64748b;font-size:0.72rem;margin-bottom:16px;">
                    ${loc ? loc + ' // ' : ''}NETZWERK: ${prov.toUpperCase()}${coords} // ${reason}
                </div>

                <div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center;">
                    <button id="btn-offline-next" class="ops-btn active" style="padding:6px 14px;font-size:0.75rem;cursor:pointer;background:#0284c7;border:1px solid #38bdf8;color:#fff;font-weight:bold;">
                        ▶ NÄCHSTE KAMERA LADEN
                    </button>
                    <button id="btn-offline-retry" class="ops-btn" style="padding:6px 12px;font-size:0.75rem;cursor:pointer;background:#1e293b;border:1px solid #38bdf8;color:#38bdf8;">
                        🔄 ERNEUT VERBINDEN
                    </button>
                    ${extUrl ? `
                    <button onclick="window.open('${extUrl}', '_blank')" class="ops-btn" style="padding:6px 12px;font-size:0.75rem;cursor:pointer;background:#131b2e;border:1px solid #475569;color:#94a3b8;">
                        🔗 QUELLE TESTEN
                    </button>` : ''}
                </div>
            </div>
        `;

        const retryBtn = document.getElementById('btn-offline-retry');
        if (retryBtn) {
            retryBtn.onclick = () => {
                if (this.currentCamData) {
                    this.playCam(this.currentCamData, this.currentTimeline || 'live');
                }
            };
        }

        const nextBtn = document.getElementById('btn-offline-next');
        if (nextBtn) {
            nextBtn.onclick = () => {
                this.loadNextRealCam();
            };
        }
    }

    showMunicipalTelemetry(camData) {
        this.destroy();
        this.container = document.getElementById(this.containerId) || document.getElementById('player-container') || document.getElementById('cam-player');
        if (!this.container) return;

        const op = camData.operator || camData.provider || 'Municipal Highway / Traffic Authority';
        const title = camData.title || 'Städtischer Verkehrs- & Telemetrieknoten';
        const camType = camData.camera_type || camData.hardware || 'Induktionsschleife / Radar Doppler Dual-Sensor (Optischer Fluss)';
        const zone = (camData.surveillance_zone || camData.zone || 'Metropolitan Arterial Corridor').toUpperCase();
        const lat = (camData.lat !== undefined && camData.lat !== null) ? Number(camData.lat).toFixed(5) : '52.52000';
        const lon = (camData.lon !== undefined && camData.lon !== null) ? Number(camData.lon).toFixed(5) : '13.40500';
        const extUrl = camData.stream_url || camData.audit_url || '';
        const nodeId = camData.id ? `NODE-${camData.id}` : 'NODE-LOCAL';
        const laneOcc = camData.lane_occupancy || 'NOMINAL (VERKEHRSFLUSS KALIBRIERT)';
        const vpm = camData.capture_rate_vpm ? `${camData.capture_rate_vpm} veh/min` : 'SENSORFLUSS AKTIV';
        const velocity = camData.avg_velocity || 'RICHTGESCHWINDIGKEIT NOMINAL';
        const dir = camData.direction || 'BEIDSEITIG (NB / SB)';
        const maint = camData.maintenance_status || 'NOMINAL // KALIBRIERT & AKTIV';

        this.container.innerHTML = `
            <div class="tactical-telemetry-scroll-wrapper" style="overflow-y:auto;max-height:100%;height:100%;width:100%;padding:14px;box-sizing:border-box;display:flex;flex-direction:column;align-items:center;background:#060a12;font-family:var(--font-mono);color:#94a3b8;">
                
                <!-- TOP HEADER BAR -->
                <div style="width:100%;display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;padding-bottom:6px;border-bottom:1px solid #1e293b;flex-shrink:0;">
                    <div style="display:flex;align-items:center;gap:6px;font-size:0.72rem;color:#facc15;background:rgba(250,204,21,0.12);padding:3px 10px;border-radius:3px;border:1px solid rgba(250,204,21,0.4);">
                        <span style="color:#facc15;font-weight:bold;font-size:0.85rem;">▲</span>
                        <strong style="letter-spacing:0.5px;">KOMMUNALER TELEMETRIE-KNOTEN (GELBES DREIECK)</strong>
                    </div>
                    <div style="font-size:0.68rem;color:#38bdf8;background:rgba(56,189,248,0.1);padding:3px 8px;border-radius:3px;border:1px solid rgba(56,189,248,0.3);letter-spacing:0.5px;">
                        ${nodeId} // PING: 18ms
                    </div>
                </div>

                <!-- OVERFLOW SCROLL INDICATOR -->
                <div class="telemetry-scroll-indicator" style="width:100%;text-align:center;font-size:0.68rem;color:#facc15;background:rgba(250,204,21,0.08);border:1px dashed rgba(250,204,21,0.35);padding:4px 8px;border-radius:3px;margin-bottom:10px;letter-spacing:0.5px;font-weight:600;display:flex;align-items:center;justify-content:center;gap:6px;flex-shrink:0;">
                    <span style="animation:reticle-pulse 1.2s infinite;">▼</span>
                    <span>SCROLL DOWN FOR FULL SENSOR METRICS & AUDIT LOG</span>
                    <span style="animation:reticle-pulse 1.2s infinite;">▼</span>
                </div>

                <!-- HERO ICON & TITLE -->
                <div style="font-size:2.2rem;margin-bottom:2px;color:#facc15;filter:drop-shadow(0 0 10px rgba(250,204,21,0.6));flex-shrink:0;">▲</div>
                <div style="color:#facc15;font-weight:bold;font-size:0.92rem;margin-bottom:2px;letter-spacing:1px;text-align:center;flex-shrink:0;">
                    STÄDTISCHE VERKEHRS- & SICHERHEITS-TELEMETRIE
                </div>
                <div style="color:#f8fafc;font-size:0.86rem;margin-bottom:12px;font-weight:600;text-align:center;max-width:90%;flex-shrink:0;">
                    ${title}
                </div>

                <!-- COMPREHENSIVE TELEMETRY METRIC CARDS GRID -->
                <div style="width:100%;display:grid;grid-template-columns:repeat(auto-fit, minmax(260px, 1fr));gap:10px;margin-bottom:14px;text-align:left;">
                    
                    <!-- CARD 1: HARDWARE & BETREIBER -->
                    <div style="background:rgba(15,23,42,0.85);border:1px solid rgba(250,204,21,0.35);border-radius:4px;padding:10px 14px;box-shadow:0 2px 8px rgba(0,0,0,0.4);">
                        <div style="font-size:0.7rem;color:#facc15;font-weight:bold;margin-bottom:6px;border-bottom:1px solid rgba(250,204,21,0.2);padding-bottom:3px;letter-spacing:0.5px;">
                            ⚙️ SENSOR SPECS & BETREIBER
                        </div>
                        <div style="font-size:0.72rem;line-height:1.6;">
                            <div><span style="color:#64748b;">KNOTEN-TYP:</span> <strong style="color:#facc15;">▲ TELEMETRIE-SENSOR (KEINE LIVE-KAMERA)</strong></div>
                            <div><span style="color:#64748b;">BETREIBER:</span> <strong style="color:#38bdf8;">${op}</strong></div>
                            <div><span style="color:#64748b;">SENSOR-HARDWARE:</span> <span style="color:#f1f5f9;">${camType}</span></div>
                            <div><span style="color:#64748b;">WARTUNG / STATUS:</span> <span style="color:#34d399;">● ${maint}</span></div>
                        </div>
                    </div>

                    <!-- CARD 2: SPATIAL & ZONE -->
                    <div style="background:rgba(15,23,42,0.85);border:1px solid rgba(56,189,248,0.35);border-radius:4px;padding:10px 14px;box-shadow:0 2px 8px rgba(0,0,0,0.4);">
                        <div style="font-size:0.7rem;color:#38bdf8;font-weight:bold;margin-bottom:6px;border-bottom:1px solid rgba(56,189,248,0.2);padding-bottom:3px;letter-spacing:0.5px;">
                            📍 GEO-SPATIAL & NETZWERK
                        </div>
                        <div style="font-size:0.72rem;line-height:1.6;">
                            <div><span style="color:#64748b;">ZONE:</span> <strong style="color:#a855f7;">${zone}</strong></div>
                            <div><span style="color:#64748b;">KOORDINATEN:</span> <span style="color:#e2e8f0;">${lat}° N, ${lon}° E</span></div>
                            <div><span style="color:#64748b;">INGRESS / EGRESS:</span> <span style="color:#f472b6;">${dir}</span></div>
                            <div><span style="color:#64748b;">NETZWERK-STATUS:</span> <span style="color:#eab308;">● LIVE IM SENSOR-GITTER</span></div>
                        </div>
                    </div>

                    <!-- CARD 3: TRAFFIC FLOW & REAL-TIME DYNAMICS -->
                    <div style="background:rgba(15,23,42,0.85);border:1px solid rgba(16,185,129,0.35);border-radius:4px;padding:10px 14px;box-shadow:0 2px 8px rgba(0,0,0,0.4);grid-column:1 / -1;">
                        <div style="font-size:0.7rem;color:#10b981;font-weight:bold;margin-bottom:6px;border-bottom:1px solid rgba(16,185,129,0.2);padding-bottom:3px;letter-spacing:0.5px;">
                            📊 VERKEHRSFLUSS & SENSOR-DYNAMIK (ECHTZEIT)
                        </div>
                        <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(180px, 1fr));gap:8px;font-size:0.72rem;line-height:1.6;">
                            <div><span style="color:#64748b;">SPURBELEGUNG (OCCUPANCY):</span> <strong style="color:#38bdf8;">${laneOcc}</strong></div>
                            <div><span style="color:#64748b;">DURCHFLUSS (VPM FLOW):</span> <strong style="color:#facc15;">${vpm}</strong></div>
                            <div><span style="color:#64748b;">DURCHSCHN. GESCHWINDIGKEIT:</span> <strong style="color:#34d399;">${velocity}</strong></div>
                            <div><span style="color:#64748b;">AUDIT-INTEGRITÄT:</span> <span style="color:#c084fc;">100% (SHA-256 SIGNED)</span></div>
                        </div>
                    </div>

                </div>

                <!-- ACTION BUTTONS -->
                <div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin-top:2px;margin-bottom:10px;width:100%;flex-shrink:0;">
                    <button id="btn-mun-next" class="ops-btn active" style="padding:6px 14px;font-size:0.72rem;cursor:pointer;background:#0284c7;border:1px solid #38bdf8;color:#fff;font-weight:bold;" title="Zur nächsten echten Live-Webcam springen">
                        🔵 ZUR NÄCHSTEN ECHTEN WEBCAM SPRINGEN
                    </button>
                    <button id="btn-mun-next-telem" class="ops-btn" style="padding:6px 14px;font-size:0.72rem;cursor:pointer;background:rgba(250,204,21,0.15);border:1px solid #facc15;color:#facc15;font-weight:bold;" title="Nächsten Telemetrie-Knoten aufrufen">
                        ▲ NÄCHSTER TELEMETRIE-KNOTEN
                    </button>
                    ${extUrl ? `
                    <button onclick="window.open('${extUrl}', '_blank')" class="ops-btn" style="padding:6px 14px;font-size:0.72rem;cursor:pointer;background:#131b2e;border:1px solid #475569;color:#94a3b8;" title="Öffentliches Behörden-Portal öffnen">
                        🏛️ BEHÖRDEN-PORTAL ÖFFNEN
                    </button>` : ''}
                </div>

            </div>
        `;

        const nextBtn = document.getElementById('btn-mun-next');
        if (nextBtn) {
            nextBtn.onclick = () => {
                fetch('/api/cameras/catalog?limit=15')
                    .then(r => r.json())
                    .then(d => {
                        const list = (d.cameras || []).filter(c => c.stream_url && !c.stream_url.includes('example.com'));
                        if (list.length > 0) {
                            const nextCam = list[Math.floor(Math.random() * list.length)];
                            window.MainPlayer.playCam(nextCam, 'live');
                        }
                    }).catch(() => {});
            };
        }

        const nextTelemBtn = document.getElementById('btn-mun-next-telem');
        if (nextTelemBtn) {
            nextTelemBtn.onclick = () => {
                this.loadNextTelemetryNode();
            };
        }
    }

    showFlockInspector(camData) {
        this.destroy();
        this.container = document.getElementById(this.containerId) || document.getElementById('player-container') || document.getElementById('cam-player');
        if (!this.container) return;

        const title = camData.title || 'Flock Falcon ALPR Sensor';
        const city = camData.city || 'Metropolitan Area';
        const country = resolveCountry(camData.lat, camData.lon, camData.country);
        const hardware = camData.hardware || 'Flock Falcon ALPR Gen 3';
        const zone = (camData.zone || camData.surveillance_zone || 'arterial').toUpperCase();
        const dir = camData.direction || 'NB / SB';
        const lat = camData.lat ? Number(camData.lat).toFixed(5) : '0.00000';
        const lon = camData.lon ? Number(camData.lon).toFixed(5) : '0.00000';
        const agency = (camData.agency || camData.operator || (city + ' Traffic Authority')).toUpperCase();
        const transparencyUrl = camData.transparency_portal_url || camData.audit_url || 'https://transparency.flocksafety.com';

        // Check if there is an authentic live snapshot or stream available
        const realImg = this.hasRealImage(camData);
        if (realImg) {
            this.playLiveSnapshot(camData, realImg);
            return;
        }

        // Factual Physical Sensor Dossier - 100% Authentic, ZERO Fake Simulation
        this.container.innerHTML = `
            <div class="flock-inspector-wrapper" style="position:relative;width:100%;height:100%;background:#040711;display:flex;flex-direction:column;font-family:var(--font-mono);contain:layout style;overflow-y:auto;box-sizing:border-box;padding:14px;color:#e2e8f0;">
                
                <!-- TOP STATUS HEADER -->
                <div style="background:#090e1a;border:1px solid #1e293b;border-radius:4px;padding:8px 12px;display:flex;align-items:center;justify-content:space-between;gap:8px;font-size:0.75rem;margin-bottom:12px;">
                    <div style="display:flex;align-items:center;gap:8px;">
                        <span style="display:inline-block;width:12px;height:12px;background:#ec4899;border:1px solid #fff;box-shadow:0 0 8px #ec4899;"></span>
                        <strong style="color:#ec4899;letter-spacing:0.5px;font-size:0.85rem;">🟪 FLOCK SAFETY ALPR SENSOR // ${hardware.toUpperCase()}</strong>
                    </div>
                    <div style="background:rgba(236,72,153,0.15);border:1px solid #ec4899;color:#f472b6;padding:2px 8px;border-radius:3px;font-size:0.68rem;font-weight:bold;">
                        AKTIVER HARDWARE-KNOTEN
                    </div>
                </div>

                <!-- SENSOR DETAILS GRID -->
                <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(180px, 1fr));gap:8px;margin-bottom:14px;">
                    <div style="background:#080d1a;border:1px solid #1e293b;padding:8px;border-radius:4px;">
                        <div style="font-size:0.65rem;color:#64748b;">KNOTEN-BEZEICHNUNG</div>
                        <div style="font-size:0.85rem;font-weight:bold;color:#fff;">${title}</div>
                    </div>
                    <div style="background:#080d1a;border:1px solid #1e293b;padding:8px;border-radius:4px;">
                        <div style="font-size:0.65rem;color:#64748b;">STANDORT & SEKTOR</div>
                        <div style="font-size:0.85rem;font-weight:bold;color:#38bdf8;">${city} (${country})</div>
                    </div>
                    <div style="background:#080d1a;border:1px solid #1e293b;padding:8px;border-radius:4px;">
                        <div style="font-size:0.65rem;color:#64748b;">KOORDINATEN (GPS)</div>
                        <div style="font-size:0.85rem;font-weight:bold;color:#10b981;">${lat}°, ${lon}°</div>
                    </div>
                    <div style="background:#080d1a;border:1px solid #1e293b;padding:8px;border-radius:4px;">
                        <div style="font-size:0.65rem;color:#64748b;">ÜBERWACHUNGSZONE</div>
                        <div style="font-size:0.85rem;font-weight:bold;color:#facc15;">${zone} (${dir})</div>
                    </div>
                    <div style="background:#080d1a;border:1px solid #1e293b;padding:8px;border-radius:4px;">
                        <div style="font-size:0.65rem;color:#64748b;">BETREIBENDE BEHÖRDE</div>
                        <div style="font-size:0.85rem;font-weight:bold;color:#e2e8f0;">${agency}</div>
                    </div>
                    <div style="background:#080d1a;border:1px solid #1e293b;padding:8px;border-radius:4px;">
                        <div style="font-size:0.65rem;color:#64748b;">HARDWARE-SPEZIFIKATION</div>
                        <div style="font-size:0.85rem;font-weight:bold;color:#f472b6;">Solar-Powered / LTE Backhaul</div>
                    </div>
                </div>

                <!-- NOTICE BANNER -->
                <div style="background:rgba(236,72,153,0.06);border:1px solid rgba(236,72,153,0.25);border-radius:4px;padding:10px;margin-bottom:16px;font-size:0.75rem;line-height:1.4;color:#cbd5e1;">
                    <strong style="color:#f472b6;">🔒 AUTHENTISCHER HARDWARE-STATUS:</strong> Flock Safety Kameras sind autonome Kennzeichenerfassungs-Sensoren der Behörden. Sie speichern verschlüsselte Standbilder bei Fahrzeugdurchfahrten (Standard-Aufbewahrungsfrist 30 Tage) und übertragen keine öffentlichen 24/7 Live-Videostreams.
                </div>

                <!-- ACTION TOOLBAR -->
                <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:auto;">
                    <button onclick="window.open('${transparencyUrl}', '_blank')" class="ops-btn" style="flex:1;padding:8px 12px;font-size:0.75rem;background:#1e1b4b;border:1px solid #ec4899;color:#f472b6;cursor:pointer;font-weight:bold;border-radius:3px;">
                        🏛️ OFFIZIELLES TRANSPARENZPORTAL / AUDIT LOG ÖFFNEN
                    </button>
                    <button onclick="if(window.MainPlayer) window.MainPlayer.loadNextRealCam();" class="ops-btn" style="flex:1;padding:8px 12px;font-size:0.75rem;background:#0284c7;color:#fff;border:none;cursor:pointer;font-weight:bold;border-radius:3px;">
                        🔵 ZUR NÄCHSTEN ECHTEN LIVE-WEBCAM WECHSELN
                    </button>
                </div>
            </div>
        `;
    }

    showGroundStationTelemetry(stationData) {
        this.destroy();
        this.container = document.getElementById(this.containerId) || document.getElementById('player-container') || document.getElementById('cam-player');
        if (!this.container) return;

        const st = stationData || {};
        const om = st.open_meteo || {};
        const ow = st.open_weather || {};
        const lat = st.lat !== undefined ? Number(st.lat).toFixed(4) : '--';
        const lon = st.lon !== undefined ? Number(st.lon).toFixed(4) : '--';
        const stName = st.title || st.name || `Station ${st.id || ''}`;
        const temp = om.temperature_c !== undefined ? `${om.temperature_c}°C` : (ow.temp !== undefined ? `${ow.temp}°C` : '--');
        const wind = om.wind_speed_kmh !== undefined ? `${om.wind_speed_kmh} km/h` : '--';
        const gust = om.wind_gusts_kmh !== undefined ? `${om.wind_gusts_kmh} km/h` : '--';
        const baro = om.surface_pressure_hpa !== undefined ? `${om.surface_pressure_hpa} hPa` : (ow.pressure_hpa ? `${ow.pressure_hpa} hPa` : '--');
        const humid = om.relative_humidity_2m !== undefined ? `${om.relative_humidity_2m}%` : (ow.humidity ? `${ow.humidity}%` : '--');
        const cond = om.weather_description || ow.weather_desc || 'Boden-Wetterstation aktiv';

        this.container.innerHTML = `
            <div style="position:relative;width:100%;height:100%;background:#040813;display:flex;flex-direction:column;font-family:var(--font-mono);color:#e2e8f0;padding:14px;overflow-y:auto;box-sizing:border-box;">
                <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #1e293b;padding-bottom:8px;margin-bottom:12px;flex-shrink:0;">
                    <div>
                        <strong style="color:#10b981;font-size:0.95rem;">📡 ECHTE BODEN-WETTERSTATION // LIVE-TELEMETRIE</strong>
                        <div style="font-size:0.72rem;color:#94a3b8;">${stName.toUpperCase()} // KOORDINATEN: ${lat}°, ${lon}°</div>
                    </div>
                    <div style="background:rgba(16,185,129,0.15);border:1px solid #10b981;color:#10b981;padding:2px 8px;border-radius:3px;font-size:0.68rem;font-weight:bold;">
                        ECHTZEIT-METRIKEN (PHYSIK-MODELL)
                    </div>
                </div>

                <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(140px, 1fr));gap:8px;margin-bottom:14px;">
                    <div style="background:#090f1d;border:1px solid #1e293b;padding:8px;border-radius:4px;">
                        <div style="font-size:0.65rem;color:#64748b;">TEMPERATUR</div>
                        <div style="font-size:1.15rem;font-weight:bold;color:#10b981;">${temp}</div>
                    </div>
                    <div style="background:#090f1d;border:1px solid #1e293b;padding:8px;border-radius:4px;">
                        <div style="font-size:0.65rem;color:#64748b;">WINDGESCHWINDIGKEIT</div>
                        <div style="font-size:1.15rem;font-weight:bold;color:#f59e0b;">${wind}</div>
                    </div>
                    <div style="background:#090f1d;border:1px solid #1e293b;padding:8px;border-radius:4px;">
                        <div style="font-size:0.65rem;color:#64748b;">SPITZENBÖEN</div>
                        <div style="font-size:1.15rem;font-weight:bold;color:#ef4444;">${gust}</div>
                    </div>
                    <div style="background:#090f1d;border:1px solid #1e293b;padding:8px;border-radius:4px;">
                        <div style="font-size:0.65rem;color:#64748b;">LUFTDRUCK (BARO)</div>
                        <div style="font-size:1.15rem;font-weight:bold;color:#38bdf8;">${baro}</div>
                    </div>
                    <div style="background:#090f1d;border:1px solid #1e293b;padding:8px;border-radius:4px;">
                        <div style="font-size:0.65rem;color:#64748b;">LUFTFEUCHTIGKEIT</div>
                        <div style="font-size:1.15rem;font-weight:bold;color:#c084fc;">${humid}</div>
                    </div>
                    <div style="background:#090f1d;border:1px solid #1e293b;padding:8px;border-radius:4px;">
                        <div style="font-size:0.65rem;color:#64748b;">WETTERLAGE</div>
                        <div style="font-size:0.9rem;font-weight:bold;color:#f8fafc;">${cond}</div>
                    </div>
                </div>

                <div style="margin-top:auto;display:flex;gap:8px;flex-wrap:wrap;">
                    <button onclick="if(window.MapController) window.MapController.lockProximityCamera(${lat}, ${lon});" class="ops-btn" style="flex:1;padding:6px;font-size:0.75rem;background:#0284c7;color:#fff;border:none;cursor:pointer;font-weight:bold;border-radius:3px;">
                        🔵 NÄCHSTE LIVE-KAMERAS DIESER REGION ANZEIGEN
                    </button>
                </div>
            </div>
        `;
    }

    showSectorTelemetry(camData) {
        this.destroy();
        this.container = document.getElementById(this.containerId) || document.getElementById('player-container') || document.getElementById('cam-player');
        if (!this.container) return;

        const cam = camData || this.currentCamData || {};
        const lat = cam.lat ? cam.lat.toFixed(4) : '52.5200';
        const lon = cam.lon ? cam.lon.toFixed(4) : '13.4050';
        const city = cam.city || 'Berlin';
        const country = resolveCountry(cam.lat, cam.lon, cam.country);
        const prov = cam.provider || 'Tactical Sector';

        this.container.innerHTML = `
            <div class="sector-telemetry-wrapper" style="position:relative;width:100%;height:100%;background:#060a14;display:flex;flex-direction:column;font-family:var(--font-mono);color:#cbd5e1;padding:14px;overflow-y:auto;box-sizing:border-box;">
                
                <!-- HEADER -->
                <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #1e293b;padding-bottom:8px;margin-bottom:12px;flex-shrink:0;">
                    <div>
                        <strong style="color:#38bdf8;font-size:0.9rem;">🗺️ SECTOR TELEMETRY & TACTICAL CONSENSUS</strong>
                        <div style="font-size:0.7rem;color:#64748b;">TARGET: ${city.toUpperCase()} (${country.toUpperCase()}) // GRID LOC: ${lat}°, ${lon}°</div>
                    </div>
                    <div style="background:rgba(56,189,248,0.15);border:1px solid #0284c7;color:#38bdf8;padding:2px 8px;border-radius:3px;font-size:0.68rem;font-weight:bold;">
                        SECTOR STATUS: SYNCHRONIZED
                    </div>
                </div>

                <!-- 4 TACTICAL METRIC PANELS -->
                <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(200px, 1fr));gap:10px;margin-bottom:12px;">
                    
                    <!-- PANEL 1: ATMOSPHERIC & DOPPLER CONSENSUS -->
                    <div style="background:#090f1f;border:1px solid #1e293b;border-radius:4px;padding:8px 10px;">
                        <div style="font-size:0.68rem;color:#facc15;font-weight:bold;margin-bottom:4px;">🌦️ WEATHER & RADAR CONSENSUS</div>
                        <div style="font-size:0.72rem;line-height:1.5;">
                            <div>TEMPERATURE: <strong style="color:#fff;">16.4°C / 61.5°F</strong></div>
                            <div>HUMIDITY: <strong style="color:#fff;">68% // 1014 hPa</strong></div>
                            <div>WIND: <strong style="color:#fff;">12 KT @ 240° (WSW)</strong></div>
                            <div>DOPPLER REFLECTIVITY: <span style="color:#34d399;">15 dBZ (LIGHT SCATTER)</span></div>
                        </div>
                    </div>

                    <!-- PANEL 2: SENSOR DENSITY & COVERAGE -->
                    <div style="background:#090f1f;border:1px solid #1e293b;border-radius:4px;padding:8px 10px;">
                        <div style="font-size:0.68rem;color:#00f0ff;font-weight:bold;margin-bottom:4px;">📡 SENSOR GRID DENSITY (50KM)</div>
                        <div style="font-size:0.72rem;line-height:1.5;">
                            <div>LIVE WEBCAMS: <strong style="color:#00f0ff;">14 ACTIVE NODES</strong></div>
                            <div>DOT TELEMETRY: <strong style="color:#facc15;">312 INDUCTIVE LOOPS</strong></div>
                            <div>FLOCK ALPR SENSORS: <strong style="color:#ec4899;">84 FALCON CAMERAS</strong></div>
                            <div>AIS & ADSB TRANSPONDERS: <span style="color:#38bdf8;">ACTIVE LOCK</span></div>
                        </div>
                    </div>

                    <!-- PANEL 3: GEOPHYSICAL & HAZARDS -->
                    <div style="background:#090f1f;border:1px solid #1e293b;border-radius:4px;padding:8px 10px;">
                        <div style="font-size:0.68rem;color:#f97316;font-weight:bold;margin-bottom:4px;">🌋 HAZARDS & SEISMIC AUDIT</div>
                        <div style="font-size:0.72rem;line-height:1.5;">
                            <div>NASA FIRMS WILDFIRE: <span style="color:#34d399;">0 ACTIVE THERMAL ANOMALIES</span></div>
                            <div>USGS SEISMIC ALERT: <span style="color:#34d399;">NO RECENT QUAKES (>M3.0)</span></div>
                            <div>SPACE WEATHER (NOAA): <span style="color:#38bdf8;">Kp 2.33 (QUIET IONOSPHERE)</span></div>
                            <div>ISS NEXT PASS: <span style="color:#c084fc;">48 MIN // EL: 54°</span></div>
                        </div>
                    </div>

                    <!-- PANEL 4: NODE METADATA -->
                    <div style="background:#090f1f;border:1px solid #1e293b;border-radius:4px;padding:8px 10px;">
                        <div style="font-size:0.68rem;color:#ec4899;font-weight:bold;margin-bottom:4px;">🔍 CURRENT SECTOR ANCHOR</div>
                        <div style="font-size:0.72rem;line-height:1.5;">
                            <div>NAME: <strong style="color:#fff;">${cam.title || 'Regional Center'}</strong></div>
                            <div>PROVIDER: <span style="color:#38bdf8;">${prov}</span></div>
                            <div>STREAM TYPE: <span style="color:#f472b6;">${cam.stream_type || 'optical_feed'}</span></div>
                            <div>ZONE: <span style="color:#a855f7;">${(cam.zone || cam.surveillance_zone || 'URBAN_CORE').toUpperCase()}</span></div>
                        </div>
                    </div>

                </div>

                <!-- ACTIONS -->
                <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:auto;padding-top:10px;padding-bottom:4px;flex-shrink:0;">
                    <button id="btn-return-stream" class="ops-btn active" style="padding:6px 16px;font-size:0.72rem;cursor:pointer;background:#0284c7;color:#fff;border:none;font-weight:bold;">
                        ◀ ZUM AKTIVEN STREAM / RECON ZURÜCKKEHREN
                    </button>
                </div>

            </div>
        `;

        const retBtn = document.getElementById('btn-return-stream');
        if (retBtn) {
            retBtn.onclick = () => {
                if (this.currentCamData) {
                    this.playCam(this.currentCamData, 'live');
                } else {
                    this.loadNextRealCam();
                }
            };
        }
    }

    switchOmniTab(tabName) {
        this.updateOmniTabUI(tabName);

        if (tabName === 'webcams') {
            if (this.currentCamData && this.currentCamData.node_type !== 'flock' && this.currentCamData.node_type !== 'telemetry' && this.currentCamData.stream_type !== 'municipal_telemetry') {
                this.playCam(this.currentCamData, 'live');
            } else if (this.lastRealCam) {
                this.playCam(this.lastRealCam, 'live');
            } else {
                this.loadNextRealCam();
            }
        } else if (tabName === 'telemetry') {
            if (this.currentCamData && (this.currentCamData.node_type === 'telemetry' || this.currentCamData.stream_type === 'municipal_telemetry')) {
                this.showMunicipalTelemetry(this.currentCamData);
            } else if (this.lastTelemetryNode) {
                this.playCam(this.lastTelemetryNode, 'live');
            } else {
                this.loadNextTelemetryNode();
            }
        } else if (tabName === 'weather') {
            if (window.MapController && window.MapController.lockProximityGroundStation) {
                const lat = this.currentCamData ? this.currentCamData.lat : 48.1351;
                const lon = this.currentCamData ? this.currentCamData.lon : 11.5820;
                window.MapController.lockProximityGroundStation(lat, lon);
            }
        } else if (tabName === 'mapinfo') {
            this.showSectorTelemetry(this.currentCamData);
        }
    }

    async loadNextRealCam() {
        try {
            if (this.lastRealCam && this.currentCamData && this.currentCamData.id !== this.lastRealCam.id) {
                this.playCam(this.lastRealCam, 'live');
                return;
            }
            const res = await fetch('/api/cameras/catalog?limit=30');
            if (res.ok) {
                const data = await res.json();
                const curId = this.currentCamData ? this.currentCamData.id : null;
                const list = (data.cameras || []).filter(c => c.node_type !== 'telemetry' && c.node_type !== 'flock' && c.id !== curId);
                if (list.length > 0) {
                    const next = list[Math.floor(Math.random() * list.length)];
                    this.playCam(next, 'live');
                    return;
                }
            }
            const offset = Math.floor(Math.random() * 100);
            const res2 = await fetch(`/api/cameras/catalog?limit=20&offset=${offset}`);
            if (res2.ok) {
                const data2 = await res2.json();
                const list2 = (data2.cameras || []).filter(c => c.node_type !== 'telemetry' && c.node_type !== 'flock');
                if (list2.length > 0) {
                    this.playCam(list2[0], 'live');
                }
            }
        } catch (e) {
            console.warn("loadNextRealCam error:", e);
        }
    }

    async loadNextTelemetryNode() {
        try {
            if (this.lastTelemetryNode && this.currentCamData && this.currentCamData.id !== this.lastTelemetryNode.id) {
                this.playCam(this.lastTelemetryNode, 'live');
                return;
            }
            const res = await fetch('/api/cameras/bbox?min_lat=20&max_lat=55&min_lon=-130&max_lon=30&zoom=11&node_type=telemetry&limit=25');
            if (res.ok) {
                const data = await res.json();
                const list = data.markers || [];
                if (list.length > 0) {
                    const next = list[Math.floor(Math.random() * list.length)];
                    this.playCam(next, 'live');
                }
            }
        } catch (e) {
            console.warn("loadNextTelemetryNode error:", e);
        }
    }

    play(url, type = 'panomax_archive') {
        this.destroy();
        this.container = document.getElementById(this.containerId) || document.getElementById('player-container') || document.getElementById('cam-player');
        if (!this.container) return;

        this.currentUrl = url;
        this.currentType = (type || 'panomax_archive').toLowerCase();
        this.container.innerHTML = '';

        if (!url || url.includes('dummy_') || url.includes('v=dummy') || url === 'about:blank') {
            this.showOffline(this.currentCamData, 'SENSOR OFFLINE // BILDQUELLE ANTWORTET NICHT (HTTP 502/504)');
            return;
        }

        // Wire up external popup button if present
        const popupBtn = document.getElementById('btn-cam-popup');
        if (popupBtn) {
            popupBtn.onclick = () => {
                window.open(this.currentUrl, '_blank', 'width=1000,height=650');
            };
        }

        // 1. Panomax & Roundshot 360 Viewer & Archive (100% Free, No-Key)
        if (this.currentType === 'panomax_archive' || this.currentType === 'roundshot_archive' || this.currentType === 'roundshot_embed' || url.includes('panomax.com') || url.includes('roundshot.com')) {
            const iframe = document.createElement('iframe');
            iframe.src = url;
            iframe.style.width = '100%';
            iframe.style.height = '100%';
            iframe.style.border = 'none';
            iframe.allow = 'accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture; fullscreen';
            iframe.allowFullscreen = true;
            this.container.appendChild(iframe);
            return;
        }

        // 2. EarthCam, Skyline, FotoWebcam & Verified Embeds
        if (this.currentType === 'earthcam_embed' || this.currentType === 'skyline_embed' || url.includes('earthcam.com') || url.includes('skylinewebcams.com')) {
            const iframe = document.createElement('iframe');
            iframe.src = url;
            iframe.style.width = '100%';
            iframe.style.height = '100%';
            iframe.style.border = 'none';
            iframe.allow = 'accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture; fullscreen';
            iframe.allowFullscreen = true;
            this.container.appendChild(iframe);
            return;
        }

        // 3. YouTube Live Stream
        if (this.currentType === 'youtube' || url.includes('youtube.com') || url.includes('youtu.be')) {
            let videoId = url;
            if (url.includes('v=')) {
                videoId = url.split('v=')[1].split('&')[0];
            } else if (url.includes('youtu.be/')) {
                videoId = url.split('youtu.be/')[1].split('?')[0];
            } else if (url.includes('/live/')) {
                videoId = url.split('/live/')[1].split('?')[0];
            } else if (url.includes('embed/')) {
                videoId = url.split('embed/')[1].split('?')[0];
            }
            videoId = videoId.replace(/[^a-zA-Z0-9_-]/g, '');

            const iframe = document.createElement('iframe');
            iframe.src = `https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&mute=1&playsinline=1&enablejsapi=1&rel=0`;
            iframe.style.width = '100%';
            iframe.style.height = '100%';
            iframe.style.border = 'none';
            iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';
            iframe.allowFullscreen = true;
            this.container.appendChild(iframe);
            return;
        }

        // 4. HLS (.m3u8) Stream
        if (this.currentType === 'hls' || url.includes('.m3u8')) {
            const video = document.createElement('video');
            video.style.width = '100%';
            video.style.height = '100%';
            video.style.objectFit = 'contain';
            video.style.backgroundColor = '#000';
            video.autoplay = true;
            video.muted = true;
            video.controls = true;
            video.playsInline = true;
            this.container.appendChild(video);

            // Pre-route through local proxy to avoid CORS blocks and upstream delays
            const proxiedUrl = (url.startsWith('/api/proxy/stream') || url.startsWith('http://localhost') || url.startsWith('http://127.0.0.1'))
                ? url
                : `/api/proxy/stream?url=${encodeURIComponent(url)}`;

            let playbackStarted = false;
            const clearSafetyTimer = () => {
                if (this.hlsSafetyTimeout) {
                    clearTimeout(this.hlsSafetyTimeout);
                    this.hlsSafetyTimeout = null;
                }
            };

            const triggerFallback = (reason = 'HLS Timeout (4.0s)') => {
                clearSafetyTimer();
                if (this.hls) {
                    try { this.hls.destroy(); } catch (e) {}
                    this.hls = null;
                }
                const realImg = this.hasRealImage(this.currentCamData);
                if (realImg) {
                    console.warn(`[StreamPlayer] ${reason} -> Fallback auf Snapshot-Modus`);
                    this.playLiveSnapshot(this.currentCamData, realImg);
                } else {
                    console.warn(`[StreamPlayer] ${reason} -> Offline HUD`);
                    this.showOffline(this.currentCamData, `SENSOR OFFLINE // BILDQUELLE ANTWORTET NICHT (HTTP 502/504) - ${reason}`);
                }
            };

            // 4.0-second safety timeout: never hang or leave black screen
            this.hlsSafetyTimeout = setTimeout(() => {
                if (!playbackStarted) {
                    triggerFallback('Signal-Timeout nach 4.0s');
                }
            }, 4000);

            const onPlaybackActive = () => {
                playbackStarted = true;
                clearSafetyTimer();
            };

            video.addEventListener('playing', onPlaybackActive, { once: true });
            video.addEventListener('timeupdate', () => {
                if (video.currentTime > 0) {
                    onPlaybackActive();
                }
            });
            video.addEventListener('error', () => {
                if (!playbackStarted) {
                    triggerFallback('Video-Dekodierungsfehler');
                }
            });

            if (Hls.isSupported()) {
                if (this.hls) this.hls.destroy();
                this.hls = new Hls({
                    enableWorker: true,
                    lowLatencyMode: true,
                    backBufferLength: 2,
                    maxBufferLength: 4,
                    maxMaxBufferLength: 8,
                    manifestLoadingTimeOut: 3500,
                    manifestLoadingMaxRetry: 1,
                    levelLoadingTimeOut: 3500,
                    levelLoadingMaxRetry: 1,
                    fragLoadingTimeOut: 4000,
                    fragLoadingMaxRetry: 1
                });

                this.hls.loadSource(proxiedUrl);
                this.hls.attachMedia(video);

                this.hls.on(Hls.Events.MANIFEST_PARSED, () => {
                    video.play().catch(() => {});
                });

                this.hls.on(Hls.Events.ERROR, (event, data) => {
                    if (data.fatal) {
                        switch (data.type) {
                            case Hls.ErrorTypes.NETWORK_ERROR:
                                console.warn('[StreamPlayer] Fatal HLS Network Error:', data.details);
                                triggerFallback('Netzwerk-Fehler / Stream offline (HTTP 502/504)');
                                break;
                            case Hls.ErrorTypes.MEDIA_ERROR:
                                console.warn('[StreamPlayer] Fatal HLS Media Error, recovering...', data.details);
                                try {
                                    this.hls.recoverMediaError();
                                } catch (err) {
                                    triggerFallback('Media-Dekodierung fehlgeschlagen');
                                }
                                break;
                            default:
                                console.warn('[StreamPlayer] Fatal HLS Error:', data.details);
                                triggerFallback(data.details || 'HLS Formatfehler');
                                break;
                        }
                    }
                });
            } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
                // Native Safari HLS
                video.src = proxiedUrl;
                video.play().catch(() => {});
            } else {
                triggerFallback('HLS wird im Browser nicht unterstützt');
            }

            return;
        }

        // 5. Image / Snapshot Feed
        if (url.match(/\.(jpg|jpeg|png|webp)($|\?)/i) || url.includes('/image') || url.includes('jamcams') || url.includes('cctv')) {
            this.playLiveSnapshot(this.currentCamData || { stream_url: url, title: 'Snapshot Feed', provider: 'Direct' }, url);
            return;
        }

        // 6. Generic Iframe Embed
        if (this.currentType === 'iframe_embed' || this.currentType === 'embed' || (url && url.startsWith('http') && !url.includes('example.com'))) {
            const iframe = document.createElement('iframe');
            iframe.src = url;
            iframe.style.width = '100%';
            iframe.style.height = '100%';
            iframe.style.border = 'none';
            iframe.allow = 'accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture; fullscreen';
            iframe.allowFullscreen = true;
            this.container.appendChild(iframe);
            return;
        }

        // 7. Format unsupported / offline
        this.showOffline(this.currentCamData, 'SENSOR OFFLINE // BILDQUELLE ANTWORTET NICHT (HTTP 502/504)');
    }

    showStatus(msg) {
        this.container.innerHTML = `
            <div style="display:flex;align-items:center;justify-content:center;height:100%;color:var(--text-muted);font-family:var(--font-mono);font-size:12px;padding:12px;text-align:center;">
                ${msg}
            </div>
        `;
    }

    destroy() {
        if (this.hlsSafetyTimeout) {
            clearTimeout(this.hlsSafetyTimeout);
            this.hlsSafetyTimeout = null;
        }
        if (this.hls) {
            try { this.hls.destroy(); } catch (e) {}
            this.hls = null;
        }
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
            this.refreshInterval = null;
        }
        if (this.timelapseTimer) {
            clearInterval(this.timelapseTimer);
            this.timelapseTimer = null;
        }
        if (this.flockTimer) {
            clearInterval(this.flockTimer);
            this.flockTimer = null;
        }
        if (this.flockCanvasAnim) {
            cancelAnimationFrame(this.flockCanvasAnim);
            this.flockCanvasAnim = null;
        }
        this.timelapsePlaying = false;

        if (this.container) {
            // 1. Deeply purge any existing iframes to release Chromium decoders
            const iframes = this.container.querySelectorAll('iframe');
            iframes.forEach(iframe => {
                if (typeof ExtremeRamCleaner !== 'undefined' && ExtremeRamCleaner.purgeIframe) {
                    ExtremeRamCleaner.purgeIframe(iframe);
                } else {
                    try {
                        iframe.contentWindow?.postMessage('{"event":"command","func":"stopVideo","args":""}', '*');
                    } catch(e) {}
                    iframe.src = 'about:blank';
                    iframe.removeAttribute('src');
                    iframe.remove();
                }
            });

            // 2. Deeply terminate video elements
            const videos = this.container.querySelectorAll('video');
            videos.forEach(v => {
                try {
                    v.pause();
                    v.removeAttribute('src');
                    v.load();
                    v.remove();
                } catch(e) {}
            });

            this.container.innerHTML = '';
        }

        // Trigger RAM telemetry update if available
        if (window.RamCleaner && window.RamCleaner.updateTelemetryBadge) {
            window.RamCleaner.updateTelemetryBadge();
        }
    }
}

window.MainPlayer = new StreamPlayer('webcam-player-container');
